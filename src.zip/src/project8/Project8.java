
package project8;

import java.util.Scanner;
import java.util.Random;
public class Project8 {

    public static void main(String[] args) {
        
        //user define the length of the array
        int size;
        Scanner in = new Scanner(System.in);
        System.out.print("Enter array size: ");
        size = in.nextInt();
        
        //creation of the array of size defined
        Random rand = new Random();
        int[] array = new int[size];
        for (int i = 0; i < array.length;i++)
            array[i] = rand.nextInt(1001);
        
        
        //time calculation BubbleSort
        long start = System.currentTimeMillis();
        SortingAlgorithms.BubbleSort(array.clone());
        long elabsed = System.currentTimeMillis() - start;
        System.out.println("Bubble Sort: "+elabsed+" (ms.)");
        
        //time calculation BubbleSortCS
        start = System.currentTimeMillis();
        SortingAlgorithms.BubbleSortCS(array.clone());
        elabsed = System.currentTimeMillis() - start;
        System.out.println("Bubble Sort (SC): "+elabsed+" (ms.)");
        
        //time calculation SelectionSort
        start = System.currentTimeMillis();
        SortingAlgorithms.SelectionSort(array.clone());
        elabsed = System.currentTimeMillis() - start;
        System.out.println("Selection Sort: "+elabsed+" (ms.)");
        
        //time calculation InsertionSort
        start = System.currentTimeMillis();
        SortingAlgorithms.InsertionSort(array.clone());
        elabsed = System.currentTimeMillis() - start;
        System.out.println("Insertion Sort: "+elabsed+" (ms.)");
    }
    
}
