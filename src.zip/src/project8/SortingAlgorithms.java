
package project8;

public class SortingAlgorithms {
    
    public static void BubbleSort(int[] array){
         
        for(int i=0; i < array.length - 1; i++)
            for(int j = 0; j < array.length-i-1;j++)
                if(array[j] > array[j+1])
                {
                    int temp = array[j];
                    array[j] = array[j+1];
                    array[j+1] = temp;
                }
    }
    
    public static void BubbleSortCS(int[] array){
        
        for(int i = 0; i < array.length - 1; i++)
        {
            boolean swap = false;
            for(int j = 0; j < array.length - i - 1; j++)
            {
                if(array[j] > array[j+1])
                {
                    int temp = array[j];
                    array[j] = array[j+1];
                    array[j+1] = temp;
                    swap = true;
                }
            }
            if(!swap)
                break;
        }
    }
    
    public static void SelectionSort(int[] array){
        
        for (int i = 0; i < array.length - 1; i++)
        {
            int index = i;
            for (int j = i+1; j < array.length; j++)
                if(array[j] < array[index])
                    index = j;
            int smallerNumber = array[index];
            array[index] = array[i];
            array[i] = smallerNumber;
        }
        
    }
    
    public static void InsertionSort(int[] array){
        
        int i;
        int key;
        int j;
        for (i = 1; i < array.length; i++)
        {
            key = array[i];
            j = i - 1;
            
            while(j >= 0 && array[j] > key)
            {
                array[j+1]=array[j];
                j = j - 1;
            }
            
            array[j+1] = key;
        }
    }
}
